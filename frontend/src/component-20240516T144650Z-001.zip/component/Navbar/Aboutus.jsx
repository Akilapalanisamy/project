import React from 'react';
import Carousel from 'react-bootstrap/Carousel';
import im1 from './im1.jpg';
import im2 from './im2.jpg';


const Aboutus = () => {
    return (
        <>
        <Carousel data-bs-theme="dark">
        <Carousel.Item>
          <img
            className="d-block w-100 h-50"
            src={im1}
            alt="First slide"
          />
          <Carousel.Caption>
            <h5>First slide label</h5>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src={im2}
            alt="Second slide"
          />
          <Carousel.Caption>
            <h5>Second slide label</h5>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="holder.js/800x400?text=Third slide&bg=e5e5e5"
            alt="Third slide"
          />
          <Carousel.Caption>
            <h5>Third slide label</h5>
            <p>
              Praesent commodo cursus magna, vel scelerisque nisl consectetur.
            </p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>
     <h1 className='text-center'>MuffinGroup – Who We Are, What We Do, and What We’ve Done</h1><br></br>
     <p className='text-center'>We founded MuffinGroup in January of 2012. In October 2014, not quite 3 years later, our team reached a significant milestone – the $1million sales mark; qualifying us for membership in the Envato Power Elite program. Who are we? How did we accomplish such a remarkable sales feat in so short a time?

Our team consists of a graphic designer, a coder, a programmer, and a jack-of-all trades support guy. We live and work in Poland. We’ve worked together for a number of years, but our turning point came in 2012, when we hooked up with ThemeForest.

We believe our accomplishments are a result of hard work, team spirit, and a determination to constantly improve upon our products.

Our name? There’s nothing symbolic about MuffinGroup. We made it up – and we designed a logo to match.</p><br></br><br></br>
<h2 className='text-center'>Our Story</h2><br></br>

Before we formed MuffinGroup, our “gang of four” worked for an interactive agency, which is where we first met. Like others having an entrepreneurial spirit, we took stock of ourselves, and decided to strike out on our own, as a design and development team.

We started by creating a WordPress theme called Doover. It was rejected, but we stuck with it, and it was eventually approved. With that successful venture under our belts, we took the next step; we quit our full-time jobs and started our own company.

Doover is still up and running. We’ve sold more than 2,000 copies, and it is one of over a dozen WordPress themes making up our product line. In fact, Doover has outsold most of our other WordPress themes, but there is one very big exception, which leads people to believe that we are a very large company.

In terms of staffing, we are a very small company. In terms of sales, we are huge; at least in terms of WordPress theme sales. That is largely because of a product of ours that recently exceeded 25,000 in sales – Be Theme.
     </>
    )
  }

export default Aboutus;
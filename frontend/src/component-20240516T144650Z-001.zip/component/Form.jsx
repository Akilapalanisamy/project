import React from 'react'
import { Link } from 'react-router-dom'
import { useNavigate } from 'react-router-dom'

function Form() {
  
    const navigate=useNavigate();
  return (
  <div> 
  <div className='form'>
    <h1 className="text-center">Login</h1>
    <label>Username:</label>
      <input
        className="input-field"
        type="text"
        name="username"
        placeholder="Username"
        
      /><br></br><br></br>
        <label>Password:</label>&nbsp;
      <input
        className="input-field"
        type="password"
        name="password"
        placeholder="Password"
        
      /><br></br><br></br>
      <button className="button" class="btn btn-outline-primary" type="submit">LogIn</button><br></br><br></br>
  <button type="button" class="btn btn-outline-primary" onClick={()=>navigate("./Sign")}>Teacher</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<button type="button" class="btn btn-outline-primary" onClick={()=>navigate("./Student")}>Student</button>

<br></br>
<div className='role'><br></br>
        <h3>Select your Role</h3>
        </div> 

<br></br>
     <h5>Click To <Link to={"/Register"}>Register</Link></h5>
    </div>
    </div>
   
  )
}
export default Form
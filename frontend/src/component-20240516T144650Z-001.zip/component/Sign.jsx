import React from 'react';
import {MDBIcon} from 'mdb-react-ui-kit';
import { useNavigate } from 'react-router-dom'; // Import the navigate function from react-router-dom


const Sign = () => {
  const navigate = useNavigate();
  const handleSubmit = (e) => {
    e.preventDefault();
    // Assuming you have some condition to check if fields are filled
    const condition = true; // Replace this with your actual condition
    if (condition) {
      // If condition is met, navigate to '/Navbar'
      navigate('/Navbar');
    } else {
      // If condition is not met, log a message
      console.log('Please fill in all fields');
    }
  };

  return (
    <div className="container my-5 mx-10">
      <div className="card mb-3" style={{ maxWidth: '2500px' }}>
        <div className="row g-0">
          <div className="col-md-6">
            <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/img1.webp" className="img-fluid rounded-start" alt="..." />
          </div>
          <div className="col-md-6">
            <div className="card-body">
              <div className="d-flex flex-row mt-2">
                <MDBIcon fas icon="cubes fa-3x me-3" style={{ color: '#ff6219' }} />
              </div>
              <h4 className="fw-normal my-10 pb-10" style={{ letterSpacing: '1px' }}>Sign into your account</h4>&nbsp;&nbsp;<br/>
              <label>Email:</label>&nbsp;&nbsp;
              <input
                className="input-field"
                type="text"
                name="Email"
                placeholder="Email"
              /><br /><br />
              <label>Password:</label>&nbsp;&nbsp;
              <input
                className="input-field"
                type="password"
                name="password"
                placeholder="Password"
              /><br/><br/>
              <button type="button" className="btn btn-outline-primary" onClick={handleSubmit}>Login</button><br />
              <a className="small text-muted" href="#!">Forgot password?</a>
              <p className="mb-5 pb-lg-2" style={{ color: '#393f81' }}>Don't have an account? <a href="#!" style={{ color: '#393f81' }}>Register here</a></p>
             
              </div>
            </div>
          </div>
        </div>
      </div>
    
  );
};

export default Sign;


       /* <MDBCard >
        <MDBRow className='g-0' pl='100' >

          <MDBCol md='6'>
            <MDBCardImage src='https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/img1.webp' alt="login form" className='rounded-start w-100'/>
          </MDBCol>

          <MDBCol md='6'>
            <MDBCardBody className='d-flex flex-column'>

              <div className='d-flex flex-row mt-2'>
                <MDBIcon fas icon="cubes fa-3x me-3" style={{ color: '#ff6219' }}/>
                
              </div>

              <h5 className="fw-normal my-4 pb-3" style={{letterSpacing: '1px'}}>Sign into your account</h5>
             <label>Email</label>
                <MDBInput wrapperClass='mb-4' id='formControlLg' type='email' size="lg"/>
                <label>Password</label>
                <MDBInput wrapperClass='mb-4' id='formControlLg' type='password' size="lg"/>

              <MDBBtn className="mb-4 px-5" color='dark' size='lg' onClick={handleSubmit}>Login</MDBBtn>
              <a className="small text-muted" href="#!">Forgot password?</a>
              <p className="mb-5 pb-lg-2" style={{color: '#393f81'}}>Don't have an account? <a href="#!" style={{color: '#393f81'}}>Register here</a></p>

              <div className='d-flex flex-row justify-content-start'>
                <a href="#!" className="small text-muted me-1">Terms of use.</a>
                <a href="#!" className="small text-muted">Privacy policy</a>
              </div>

            </MDBCardBody>
          </MDBCol>

        </MDBRow>
      </MDBCard>

    </MDBContainer>  */

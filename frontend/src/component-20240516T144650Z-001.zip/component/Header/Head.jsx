import React from 'react'
const Head= () =>{
    return(
        <div>
            <section className='head'>
                <div className="conatiner felxSB">
                    <div className='logo'>
                        <h1>MasterSkill</h1>
                        <span>Online Education & Learning</span>
                        </div>
                        <div className='social'>
                            <i className='fab fa-facebook-f-icon'></i>
                            <i className='fab fa-instagram'></i>

                        </div>
                </div>
            </section>
        </div>
    )
}
export default Head
import React from 'react';

const CoursePage = () => {
    return (
        <div className="popular page_section">
            <div className="container">
                <div className="row">
                    <div className="col">
                        <div className="section_title text-center">
                            <h1>Popular Courses</h1>
                        </div>
                    </div>
                </div>

                <div className="row course_boxes">
                    {/* Popular Course Items */}
                    {courses.map((course, index) => (
                        <div key={index} className="col-lg-4 course_box">
                            <div className="card">
                                <img className="card-img-top" src={"https://www.training-dev.fr/Img/Category/Js.png"} alt={course.alt} />
                                <div className="card-body text-center">
                                    <div className="card-title"><h2>JavaScrpit</h2></div>
                                    <div className="card-text">{course.description}</div>
                                </div>
                                <div className="price_box d-flex flex-row align-items-center">
                                    <div className="course_author_image">
                                        <img src={course.authorImage} alt={course.authorAlt} />
                                    </div>
                                    <div className="course_author_name">{course.authorName}, <span>{course.authorRole}</span></div>
                                    <div className="course_price d-flex flex-column align-items-center justify-content-center"><span>{course.price}</span></div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

// Sample data for courses
const courses = [
    {
        image: "images/course_1.jpg",
        alt: "https://unsplash.com/@kellybrito",
        title: "A complete guide to design",
        link: "courses.html",
        description: "Adobe Guide, Layes, Smart Objects etc...",
        authorImage: "images/author.jpg",
        authorAlt: "https://unsplash.com/@mehdizadeh",
        authorName: "Michael Smith",
        authorRole: "Author",
        price: "$29"
    },
    // Add more courses data here
];

export default CoursePage;

